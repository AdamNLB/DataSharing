package org.example;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        try {
            // Učitavanje tabela iz fajlova
            Map<String, List<List<String>>> tables = EmailWithProxy.loadTables();

            // Generisanje email tela
            String emailBody = EmailWithProxy.generateEmailBody(tables);

            // Slanje emaila sa proxy-jem
            EmailWithProxy.sendEmailWithProxy(emailBody);
        } catch (IOException exception){
            System.out.println("tekst");
        }
    }
}
