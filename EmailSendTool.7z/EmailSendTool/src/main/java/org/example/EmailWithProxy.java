package org.example;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.simplejavamail.api.email.Email;
import org.simplejavamail.api.mailer.Mailer;
import org.simplejavamail.api.mailer.config.TransportStrategy;
import org.simplejavamail.email.EmailBuilder;
import org.simplejavamail.mailer.MailerBuilder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class EmailWithProxy {
    public static Map<String, List<List<String>>> loadTables() throws IOException {
        Map<String, List<List<String>>> tables = new HashMap<>();

        // Parsiranje fail.txt
        List<String> failLines = Files.readAllLines(Paths.get("C:\\Users\\ZlatkovicA\\IdeaProjects\\NLB-Group-Retail-Web\\results\\fail.txt"));
        tables.put("Fail Table", parseHtmlTable(failLines));

        // Parsiranje res.txt
        List<String> resLines = Files.readAllLines(Paths.get("C:\\Users\\ZlatkovicA\\IdeaProjects\\NLB-Group-Retail-Web\\results\\res.txt"));
        tables.put("Result Summary", parseHtmlTable(resLines));

        // Parsiranje daysRes.txt
        List<String> daysResLines = Files.readAllLines(Paths.get("C:\\Users\\ZlatkovicA\\IdeaProjects\\NLB-Group-Retail-Web\\results\\daysRes.txt"));
        tables.put("Daily Results", parseHtmlTable(daysResLines));

        // Parsiranje days.txt (plain text)
        List<String> daysLines = Files.readAllLines(Paths.get("C:\\Users\\ZlatkovicA\\IdeaProjects\\NLB-Group-Retail-Web\\results\\days.txt"));
        tables.put("Plain Results", parsePlainTextData(daysLines));

        return tables;
    }

    private static List<List<String>> parseHtmlTable(List<String> lines) {
        String htmlContent = String.join("\n", lines);
        Document document = Jsoup.parse(htmlContent);
        Element table = document.selectFirst("table");

        List<List<String>> tableData = new ArrayList<>();

        if (table != null) {
            for (Element row : table.select("tr")) {
                List<String> rowData = new ArrayList<>();
                for (Element cell : row.select("th, td")) {
                    rowData.add(cell.text());
                }
                tableData.add(rowData);
            }
        }
        return tableData;
    }

    private static List<List<String>> parsePlainTextData(List<String> lines) {
        List<List<String>> table = new ArrayList<>();
        for (String line : lines) {
            table.add(Arrays.asList(line.split(";")));
        }
        return table;
    }

    // 2. Generisanje HTML email tela
    public static String generateEmailBody(Map<String, List<List<String>>> tables) {
        StringBuilder sb = new StringBuilder();
        sb.append("<html><body>");

        for (Map.Entry<String, List<List<String>>> entry : tables.entrySet()) {
            sb.append("<h2>").append(entry.getKey()).append("</h2>");
            sb.append("<table border='1'>");
            for (List<String> row : entry.getValue()) {
                sb.append("<tr>");
                for (String cell : row) {
                    sb.append("<td>").append(cell).append("</td>");
                }
                sb.append("</tr>");
            }
            sb.append("</table><br>");
        }

        sb.append("</body></html>");
        return sb.toString();
    }

    // 3. Slanje emaila koristeći Simple Java Mail
    public static void sendEmailWithProxy(String emailBody) {
        // Konfiguracija mail servera
        Mailer mailer = MailerBuilder
                .withSMTPServer("smtp.gmail.com", 587, "adamzlatkovicdtc@gmail.com", "Beograd123")
                .withTransportStrategy(TransportStrategy.SMTP)
                .withProxy("http://ctmg02.nlb.si", 8080, "ZlatkovicA", "97i6LC#Svm3086%5")
                .buildMailer();

//        // Kreiranje emaila
//        Email email = Email.builder()
//                .from("Your Name", "sender@example.com")
//                .to("Recipient Name", "recipient@example.com")
//                .withSubject("Automated Test Results")
//                .withHTMLText(emailBody)
//                .build();

        Email email = EmailBuilder.startingBlank()
                .from("adamzlatkovicdtc@gmail.com")
                .to("Jovan", "jovan.jacov@dtc.rs")
                .to("Adam", "adam.zlatkovic@dtc.rs")
                .withSubject("Automation status")
                .withHTMLText(emailBody)
                .withPlainText("THIS IS PLAIN TEXT!")
                .buildEmail();

        // Slanje emaila
        mailer.sendMail(email);
        System.out.println("Email sent successfully!");
    }
}
