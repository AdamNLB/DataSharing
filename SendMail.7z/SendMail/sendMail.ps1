$from = "automation@nlb.si"
$to = Get-Content -Path mailList.txt
$fileList = Get-Content -Path fileList.txt
$smtp = "mail.dtc.rs"
$currentDate = Get-Date -UFormat "%m/%d/%Y"
$subject = "12/30/2022 Automation test results UAT"
$secpasswd = ConvertTo-SecureString "Dobrodosao2022" -AsPlainText -Force

$mycreds = New-Object System.Management.Automation.PSCredential ("jovan.jacov@dtc.rs", $secpasswd)

$bodyB = Get-Content -Path beginMail.txt -Raw
$bodyD = Get-Content -Path "C:\Users\Jovan Jacov\IdeaProjects\DTC Test Repo\results\daysRes.txt" -Raw
$bodyF = Get-Content -Path "C:\Users\Jovan Jacov\IdeaProjects\DTC Test Repo\results\fail.txt" -Raw
$bodyR = Get-Content -Path "C:\Users\Jovan Jacov\IdeaProjects\DTC Test Repo\results\res.txt" -Raw
$bodyE = Get-Content -Path endMail.txt -Raw

$body = $bodyB + "<BR>" + $bodyR + "<BR>" + "<BR>" + $bodyF + "<BR>" + $bodyD + $bodyE
#$body =  $bodyE

#$body

#Send-MailMessage -To $to -From $from -Subject $subject -Body $body -Credential $mycreds -SmtpServer $smtp -DeliveryNotificationOption Never -BodyAsHtml -Port 25
Send-MailMessage -To $to -From $from -Subject $subject -Body $body -Credential $mycreds -Attachment $fileList -SmtpServer $smtp -DeliveryNotificationOption Never -BodyAsHtml -Port 25